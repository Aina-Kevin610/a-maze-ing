"""
Maze Generator - A reusable Python module for generating perfect and imperfect mazes.

Example usage:
    from maze_generator import MazeGenerator
    
    # Create a maze with custom parameters
    generator = MazeGenerator(width=20, height=15, perfect=True, seed=42)
    
    # Access the generated maze structure
    maze = generator.get_maze()
    
    # Get the solution path
    solution = generator.get_solution()
    
    # Export to file
    generator.export_to_file("output.txt")
"""

from maze_generator.maze_gen import Maze as MazeGenerator

__version__ = "1.0.0"
__author__ = "42 Student"
__all__ = ["MazeGenerator"]
